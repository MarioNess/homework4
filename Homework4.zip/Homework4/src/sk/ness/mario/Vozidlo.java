package sk.ness.mario;

public interface Vozidlo {
    Integer popis(String znacka);
}
